<?php
/**
 * 首页
 *
 * @package index
 */
?>

<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
  <style>

  </style>
</head>
<body>
		<script src="https://cdn.bootcss.com/jquery/3.4.1/jquery.js"></script>
	</head>
	<body>


    
 

<div id="indexonepagemain">
	<h1 id="title">truttty</h1>
	<h3 id="head">历 数 前 生</h3> <br>
	<div id="indexonepage">

	</div>
</div>
<br />
<br />
<br />
<div class="indexarrow">
			<svg class="home_arrow bou" width="39" height="16" viewBox="0 0 39 16" fill="none"
				xmlns="http://www.w3.org/2000/svg">
				<path d="M2 2L19.5 14L37 2" stroke="#A0A0A0" stroke-width="3" stroke-linecap="round"
					stroke-linejoin="round"></path>
			</svg>
		</div>
		</div>

			<div class="peo_box1 peo_box">
				<div id="index1">
					<div class="title">
						<img src="https://fravilion.top/usr/uploads/2023/06/3546408597.jpg" alt="">
					</div>

					<div class="peo_box2 peo_box">
						<h1 class="newtitle">这是一个什么网站？</h1>
						<p class="newtext">无用但美好的事情，宏大叙事的解构，分化的我们，生命在岁月中刻下的痕迹，人与人之间拉远的距离，反抗与妥协，生命的终结......</p>
						<div class="peo_box3 peo_box">
							<p>建立本网站的理由和意义并不重要。毕竟人生短短几十年，甚至悲观来说，可能这个时代只是人类进程上的一段弯路。</p>
							<p class="En">Everything is nothing</p>
							<p>所以，我存在的意义是什么呢？</p>
							<p class="En">So I think,therefore I am.</p>
							<p>人不能一直固步自封融汇自洽。形而上学的理论无法打败感受，我需要一种即时的反馈。</p>
							<p class="En">So I grasp, it doesn't matter if there is..</p>
							<p>这就是这个网站建立的初衷。仅此而已。</p>
							<p class="En">And So?</p>
							<p>这也是一块永恒无用的墓碑。</p>
						</div>
					</div>

				</div>
			</div>
<br /><br />
			<div class="peo_box4 peo_box">
				<aside>
					<div>
						<div>verson #1.9.3 </div>
						<div>24 Jul, 2023</div>
						<div>The info of blog</div>
					</div>
				</aside>
				<div id="information">
					<div id="info">

						<div id="newpost">
							<div>
								<a class="newpost posthr peo_box5 peo_box"
									href="https://fravilion.top/index.php/blog/" target="_blank">
									<span>-内容-</span>
									<p>这是一片不会被别人搜索来的净土。<br>我认为每个博客就像是无垠的海面上漂浮的冰山，一直孤独的随着洋流运动，在旅途中可能与其他冰山相撞，最后互相留下对方的痕迹。
										<br><br>为什么一个本想专注自身的网站要有友链？<br>
										因为这座冰山渴望相遇，就算最后后沉入大海。
										所有来到冰山上的人啊，我将为你祝福。
									</p>
								</a>
								<br>
								<a class="newpost posthr peo_box6 peo_box" href="http://www.typecho.org/"
									target="_blank">
									<span>-主题-</span>
									<p>- 主题以个人审美为主，就本人认为，设计和内容是创作中同等重要的部分。而为了完全符合心意，我在typecho原生主题“Typecho
										Replica
										Theme”的基础上修改得到目前的主题。
										它被命名为：11gray<br>
										<br>
										- 主题无法分享 它已经和网站内容融为一体了 如果想参考源码放在github了
										如果你有什么好的建议可以留言告诉我，如果想要交个朋友那更是欢迎。
									</p>
								</a>
							</div>
							<div>
								<a class="newpost hogwarts peo_box7 peo_box"
									href="https://fravilion.top/index.php/aboutme.html" style="overflow-y:auto;">
									<span>博客大事记</span>
									<p class="ph">2022.1.31
										网站<strong>MUS</strong>上线，使用typecho驱动<br>
										2022.3.13
										更名为<strong>trunion</strong>，<strong>MUS服务器</strong>被收录其中，主题改为handsome<br>
										2022.7.31 主题更换为Initial。<br>
										2022.12.25 网站更名为<strong>固 北
											阁</strong>，转为wordpress，同时尝试脱离博客平台<br>
										2023.1.31 由于其他原因，<strong>MUS</strong>暂时关服<br>
										2023.2.17 回归typecho，不使用其余主题<br>
										2023.2.25 界面主题重构，大量数据重置<br>
										2023.3.19 11gray主题大量重写<br>
										2023.5.2 决定每个月刷新一次阅读数量的数据<br>
										2023.7.24 更改风格 与 设计语言</p>

								</a>
							</div>

						</div>
					</div>
				</div>
			</div>


			<br />
			<br />
<br />
			<div class="peo_box8 peo_box" style="text-align: right; font-weight: bold;height: 10vh;">
				<span>※ 全站采用 <a href="https://creativecommons.org/licenses/by-nc-sa/3.0/cn/">
						CC BY-NC-SA 3.0 CN</a>进行许可。<br>
					2022-<?php echo date('Y'); ?> <a id="a"
						href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>&nbsp;版权所有.
					<?php _e('由 <a id="a" href="http://www.typecho.org">Typecho</a> 强力驱动'); ?>.
				</span>
			</div>

			<style>
				.foooo {
					position: fixed;
					top: 80%;
					width: 100%;

				}
			</style>
		<script>
//首页逐渐显示
$(function(){$(document).on('scroll',function(){var h=$(window).scrollTop();var maxh=$(document).height();var currh=$(window).height();var num=Math.ceil((h-500)/160);var str=".peo_box"+num;if(h>100&&h<(maxh-currh-1)){$(str).addClass('lishow')}else if(h>=(maxh-currh-1)){$('.peo_box').addClass('lishow')}else{$('.peo_box').removeClass('lishow')}})});

		</script>
<script data-no-instant>InstantClick.init();</script>
	</body>
</html>



